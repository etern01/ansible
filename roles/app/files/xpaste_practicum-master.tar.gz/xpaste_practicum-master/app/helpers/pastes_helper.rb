module PastesHelper
end
